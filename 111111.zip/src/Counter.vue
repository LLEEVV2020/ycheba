<template>
    <div>
        <h2>Counter {{counter}}</h2>

        <label for=""><input type="radio" value="111111" v-model="vocil">111111</label>
        <label for=""><input type="radio" value="222222" v-model="vocil">222222</label>
        <label for=""><input type="radio" value="333333" v-model="vocil">333333</label>

        
        <hr>

        

        <p>Название отсека -  {{ peopleOb[perelitiv].name }}</p>
        <ul>
          <li
            v-for="(item, index) in peopleOb[perelitiv].list" 
            :key="item.id"
          >
            {{ index + 1 }}. {{ item.img }} <br>
            {{ item.text }}
          </li>
          
        </ul>
        <p>Левая картинка - {{ peopleOb[perelitiv].leftimg }}</p>
        <p>{{perelitiv}}</p>

        
        <button class="btn btn-success" @click="counterPlus()" >Add</button>
        <button class="btn btn-danger" @click="counterMinus()" >Minus</button>
        <hr>

        <input type="text" v-model="postTitle" placeholder="title"/>
        <input type="text" v-model="postBody" placeholder="body"/>
        <input type="button" @click="createPost()" value="submit">
        <hr>
        <p>{{otvet}}</p>
    </div>
</template>

<script>
import axios from 'axios'

export default {
    data () {
        return {
            postBody: null,
            postTitle: null,
            otvet: null,
            perelitiv: 0,

            vocil: ['222222'],
            
            peopleOb: [
              {/** 1 */
                name: 'Выберите, поставить окно или остеклить балкон?', 
                leftimg: '157.jpg',
                list: [
                  {
                    img: '5c1cc65da5e8e2.57496163.png',
                    text: 'Поставить окно'
                  },
                  {
                    img: '5c1cc65e0c9de5.98850471.png',
                    text: 'Остеклить балкон'
                  }
                ]
              },
              {/** 2 */
                name: 'Будем ставить в квартиру или в частный дом?', 
                leftimg: '165.jpg',
                list: [
                  {
                    img: '5c1cc6974f5ff9.06336966.jpeg',
                    text: 'В квартиру'
                  },
                  {
                    img: '5c1cc697690c47.91064385.jpeg',
                    text: 'В частный дом'
                  }
                ]
              },
              {/** 3 */
                name: 'В какой дом нужна установка: в панельный или в кирпичный?', 
                leftimg: '149.jpg',
                list: [
                  {
                    img: '5c1cc6c936c049.15542903.jpeg',
                    text: 'В панельный дом'
                  },
                  {
                    img: '5c1cc6c9462524.33902767.jpeg',
                    text: 'В кирпичный дом'
                  }
                ]
              },
              {/** 4 */
                name: 'Какой профиль интересует?', 
                leftimg: '164.jpg',
                list: [
                  {
                    img: '5c1cd3ec2f1482.08448542.jpeg',
                    text: 'Veka'
                  },
                  {
                    img: '5c1cc743d27ad0.03039724.jpeg',
                    text: 'Rehau'
                  },
                  {
                    img: '5c1cc743e8be82.40256857.jpeg',
                    text: 'KBE'
                  },
                  {
                    img: '5c1cd1b2f371d7.66492810.jpeg',
                    text: 'Artec'
                  },
                  {
                    img: '5c1cd33fe72b84.46786573.jpeg',
                    text: 'Неважно'
                  }
                ]
              },
              {/** 5 */                
                name: 'Выберите цвет изделия', 
                leftimg: '161.jpg',
                list: [
                  {
                    img: '5c1cc7eb382994.72069783.jpeg',
                    text: 'Белое'
                  },
                  {
                    img: '5c1cc7e2ef5ed3.20291533.jpeg',
                    text: 'Цветное (с ламинацией)'
                  }
                ]
              },
              {/** 6 */
                name: 'Вам нужна установка?', 
                leftimg: '156.jpg',
                list: [
                  {
                    img: null,
                    text: 'Да'
                  },
                  {
                    img: null,
                    text: 'Нет'
                  }
                ]
              },
              {/** 7 */
                name: 'С отделкой или без отделки?', 
                leftimg: '155.jpg',
                list: [
                  {
                    img: null,
                    text: 'Да'
                  },
                  {
                    img: null,
                    text: 'Нет'
                  }
                ]
              }
            ],
            
        }
    },
    computed: {
        counter(){
            return this.$store.getters.computedCouner
        }
    },
  methods: {
    createPost () {
      axios({
        method: 'post',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        url: 'https://copy.css-world.ru/form.php',
        data: {
            firstName: this.postTitle,
            lastName: this.postBody,
            vocil: this.vocil
        }
      })
      .then(response => {
          this.otvet = response.data
          console.log(response)
        })
      .catch(function (error) {
        console.log(error);
      });

    },
    addPost(response_data){
      this.otvet = addPost(response_data)

    },
    counterPlus(){
        if(this.perelitiv >= this.peopleOb.length - 1){
          return this.peopleOb.length
        }
        this.perelitiv++;

      },
      counterMinus(){
          if(this.perelitiv <= 0){
          return 0
        }
        this.perelitiv--;
      }
  }
}
</script>

<style lang="scss" scoped>
  
  
</style>